<?php
require_once 'includes/config.php';
requireLogin();

$userId = getUserId();
$role = getUserRole();

$error = '';
$success = '';

// Handle review submission (Customer)
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['submit_review'])) {
    $chefId = intval($_POST['chef_id']);
    $rating = intval($_POST['rating']);
    $comment = sanitize($_POST['comment']);

    if ($rating < 1 || $rating > 5) {
        $error = "Please choose a rating between 1 and 5 stars.";
    } elseif (empty($comment)) {
        $error = "Please write a comment.";
    } else {
        $insert_q = "INSERT INTO reviews (user_id, chef_id, rating, comment) VALUES ('$userId', '$chefId', '$rating', '$comment')";
        if (mysqli_query($conn, $insert_q)) {
            $success = "Review submitted successfully! Thank you for your feedback.";
        } else {
            $error = "Failed to submit review.";
        }
    }
}

// Fetch lists
$reviews = [];
$chefs = [];

if ($conn) {
    if ($role == 'customer') {
        // Fetch customer's own reviews
        $rev_q = "SELECT r.*, u.name as chef_name, c.speciality 
                  FROM reviews r 
                  JOIN chefs c ON r.chef_id = c.chef_id 
                  JOIN users u ON c.user_id = u.id 
                  WHERE r.user_id = '$userId' 
                  ORDER BY r.review_id DESC";
        $reviews = mysqli_query($conn, $rev_q);

        // Fetch list of chefs to write review for
        $chef_list_q = "SELECT c.chef_id, u.name, c.speciality 
                        FROM chefs c 
                        JOIN users u ON c.user_id = u.id";
        $chefs = mysqli_query($conn, $chef_list_q);

    } elseif ($role == 'chef') {
        $chefId = getChefId($userId);
        // Fetch reviews received by chef
        $rev_q = "SELECT r.*, u.name as customer_name 
                  FROM reviews r 
                  JOIN users u ON r.user_id = u.id 
                  WHERE r.chef_id = '$chefId' 
                  ORDER BY r.review_id DESC";
        $reviews = mysqli_query($conn, $rev_q);
    }
}

include 'includes/header.php';
?>

<div class="dashboard-grid">
    <!-- Sidebar Navigation -->
    <aside class="sidebar">
        <div class="sidebar-profile">
            <div class="profile-avatar">
                <?php echo strtoupper(substr(getUserName(), 0, 1)); ?>
            </div>
            <h3><?php echo htmlspecialchars(getUserName()); ?></h3>
            <span class="profile-role"><?php echo $role; ?></span>
        </div>
        <ul class="sidebar-menu">
            <li><a href="dashboard.php" class="sidebar-menu-link"><i class='bx bx-grid-alt'></i> Dashboard</a></li>
            <?php if ($role == 'customer'): ?>
                <li><a href="dishes.php" class="sidebar-menu-link"><i class='bx bx-dish'></i> Browse Dishes</a></li>
                <li><a href="order.php" class="sidebar-menu-link"><i class='bx bx-receipt'></i> My Orders</a></li>
                <li><a href="booking.php" class="sidebar-menu-link"><i class='bx bx-calendar'></i> Book Chef</a></li>
                <li><a href="membership.php" class="sidebar-menu-link"><i class='bx bx-crown'></i> Royal Club</a></li>
                <li><a href="review.php" class="sidebar-menu-link active"><i class='bx bx-star'></i> Give Review</a></li>
            <?php elseif ($role == 'chef'): ?>
                <li><a href="dishes.php" class="sidebar-menu-link"><i class='bx bx-plus-circle'></i> Manage Dishes</a></li>
                <li><a href="order.php" class="sidebar-menu-link"><i class='bx bx-list-check'></i> Orders Received</a></li>
                <li><a href="booking.php" class="sidebar-menu-link"><i class='bx bx-calendar-event'></i> Bookings Schedule</a></li>
                <li><a href="review.php" class="sidebar-menu-link active"><i class='bx bx-message-square-detail'></i> Reviews Received</a></li>
            <?php endif; ?>
        </ul>
    </aside>

    <!-- Main Content Area -->
    <section class="dashboard-main">
        <div>
            <h2>Reviews & Rating Feedback</h2>
            <p style="color: var(--text-secondary);"><?php echo ($role == 'chef') ? 'View feedback submitted by customers.' : 'Submit ratings and reviews for our chef services.'; ?></p>
        </div>

        <?php if (!empty($error)): ?><div class="alert alert-danger"><?php echo $error; ?></div><?php endif; ?>
        <?php if (!empty($success)): ?><div class="alert alert-success"><?php echo $success; ?></div><?php endif; ?>

        <?php if ($role == 'customer'): ?>
            <!-- Review submission form -->
            <div class="table-panel">
                <h3>Write a Review</h3>
                <form action="review.php" method="POST" style="margin-top: 15px;">
                    <div style="display: grid; grid-template-columns: 2fr 1fr; gap: 20px;">
                        <div class="form-group">
                            <label for="chef_id">Select Chef</label>
                            <select name="chef_id" id="chef_id" class="form-control" required>
                                <?php if ($chefs && mysqli_num_rows($chefs) > 0): ?>
                                    <?php while ($chef = mysqli_fetch_assoc($chefs)): ?>
                                        <option value="<?php echo $chef['chef_id']; ?>">
                                            <?php echo htmlspecialchars($chef['name']); ?> (<?php echo htmlspecialchars($chef['speciality']); ?>)
                                        </option>
                                    <?php endwhile; ?>
                                <?php else: ?>
                                    <option value="">No chefs available</option>
                                <?php endif; ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="rating">Rating (Stars)</label>
                            <select name="rating" id="rating" class="form-control" required>
                                <option value="5">★★★★★ (5/5)</option>
                                <option value="4">★★★★☆ (4/5)</option>
                                <option value="3">★★★☆☆ (3/5)</option>
                                <option value="2">★★☆☆☆ (2/5)</option>
                                <option value="1">★☆☆☆☆ (1/5)</option>
                            </select>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="comment">Your Review Feedback</label>
                        <textarea name="comment" id="comment" class="form-control" rows="3" placeholder="Share your experience here... How was the meal?" required></textarea>
                    </div>
                    <button type="submit" name="submit_review" class="btn btn-primary"><i class='bx bx-check'></i> Submit Review</button>
                </form>
            </div>
        <?php endif; ?>

        <!-- List reviews -->
        <div>
            <h3><?php echo ($role == 'customer') ? 'My Reviews History' : 'Feedback Received'; ?></h3>
            <div class="reviews-grid">
                <?php if ($reviews && mysqli_num_rows($reviews) > 0): ?>
                    <?php while ($row = mysqli_fetch_assoc($reviews)): ?>
                        <div class="review-bubble">
                            <div class="review-stars">
                                <?php 
                                for ($i = 1; $i <= 5; $i++) {
                                    if ($i <= $row['rating']) {
                                        echo "<i class='bx bxs-star'></i>";
                                    } else {
                                        echo "<i class='bx bx-star'></i>";
                                    }
                                }
                                ?>
                            </div>
                            <p class="review-comment">"<?php echo htmlspecialchars($row['comment']); ?>"</p>
                            <div class="review-author">
                                <span class="review-author-name">
                                    <?php echo htmlspecialchars(($role == 'customer') ? $row['chef_name'] : $row['customer_name']); ?>
                                </span>
                                <span style="font-size: 0.8rem;">
                                    <?php echo date('M d, Y', strtotime($row['created_at'])); ?>
                                </span>
                            </div>
                        </div>
                    <?php endwhile; ?>
                <?php else: ?>
                    <p style="grid-column: 1/-1; text-align: center; color: var(--text-muted);">No reviews posted yet.</p>
                <?php endif; ?>
            </div>
        </div>
    </section>
</div>

<?php include 'includes/footer.php'; ?>
