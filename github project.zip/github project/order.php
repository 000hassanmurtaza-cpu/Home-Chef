<?php
require_once 'includes/config.php';
requireLogin();

$userId = getUserId();
$role = getUserRole();

$error = '';
$success = '';

// Handle status updates by Chef or Admin
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['update_status'])) {
        $orderId = intval($_POST['order_id']);
        $newStatus = sanitize($_POST['new_status']);
        
        if ($role == 'chef') {
            $chefId = getChefId($userId);
            // Verify Chef owns this dish
            $check_q = "SELECT o.order_id 
                        FROM orders o 
                        JOIN dishes d ON o.dish_id = d.dish_id 
                        WHERE o.order_id = '$orderId' AND d.chef_id = '$chefId'";
            $check_res = mysqli_query($conn, $check_q);
            if (mysqli_num_rows($check_res) > 0) {
                $update_q = "UPDATE orders SET status = '$newStatus' WHERE order_id = '$orderId'";
                if (mysqli_query($conn, $update_q)) {
                    $success = "Order status updated to $newStatus.";
                } else {
                    $error = "Failed to update order status.";
                }
            } else {
                $error = "Unauthorized attempt to modify order.";
            }
        } elseif ($role == 'admin') {
            $update_q = "UPDATE orders SET status = '$newStatus' WHERE order_id = '$orderId'";
            if (mysqli_query($conn, $update_q)) {
                $success = "Order status updated to $newStatus by Admin.";
            } else {
                $error = "Failed to update order status.";
            }
        }
    }

    // Handle customer placing order
    if (isset($_POST['place_order'])) {
        $dishId = intval($_POST['dish_id']);
        $quantity = intval($_POST['quantity']);

        if ($quantity <= 0) {
            $error = "Please choose a valid quantity.";
        } else {
            // Get unit price
            $price_q = mysqli_query($conn, "SELECT price FROM dishes WHERE dish_id = '$dishId'");
            if ($price_q && mysqli_num_rows($price_q) > 0) {
                $dish = mysqli_fetch_assoc($price_q);
                $unitPrice = $dish['price'];
                $totalPrice = $unitPrice * $quantity;

                $insert_q = "INSERT INTO orders (user_id, dish_id, quantity, total_price, status) 
                             VALUES ('$userId', '$dishId', '$quantity', '$totalPrice', 'Pending')";
                if (mysqli_query($conn, $insert_q)) {
                    $_SESSION['flash_success'] = "Order placed successfully! Total: $" . number_format($totalPrice, 2);
                    header("Location: order.php");
                    exit();
                } else {
                    $error = "Failed to place order.";
                }
            } else {
                $error = "Dish not found.";
            }
        }
    }
}

// Fetch relevant orders depending on role
$orders = [];
if ($conn) {
    if ($role == 'customer') {
        $orders_q = "SELECT o.*, d.dish_name, d.price as unit_price, u.name as chef_name 
                     FROM orders o 
                     JOIN dishes d ON o.dish_id = d.dish_id 
                     JOIN chefs c ON d.chef_id = c.chef_id
                     JOIN users u ON c.user_id = u.id
                     WHERE o.user_id = '$userId' 
                     ORDER BY o.order_id DESC";
        $orders = mysqli_query($conn, $orders_q);
    } elseif ($role == 'chef') {
        $chefId = getChefId($userId);
        $orders_q = "SELECT o.*, d.dish_name, d.price as unit_price, u.name as customer_name 
                     FROM orders o 
                     JOIN dishes d ON o.dish_id = d.dish_id 
                     JOIN users u ON o.user_id = u.id
                     WHERE d.chef_id = '$chefId' 
                     ORDER BY o.order_id DESC";
        $orders = mysqli_query($conn, $orders_q);
    } elseif ($role == 'admin') {
        $orders_q = "SELECT o.*, d.dish_name, dc.name as chef_name, uc.name as customer_name 
                     FROM orders o 
                     JOIN dishes d ON o.dish_id = d.dish_id 
                     JOIN chefs c ON d.chef_id = c.chef_id
                     JOIN users dc ON c.user_id = dc.id
                     JOIN users uc ON o.user_id = uc.id
                     ORDER BY o.order_id DESC";
        $orders = mysqli_query($conn, $orders_q);
    }
}

// Check if showing checkout form for customer
$show_checkout = false;
$selected_dish = null;
if ($role == 'customer' && isset($_GET['dish_id'])) {
    $dishId = intval($_GET['dish_id']);
    $dish_q = mysqli_query($conn, "SELECT d.*, u.name as chef_name FROM dishes d JOIN chefs c ON d.chef_id = c.chef_id JOIN users u ON c.user_id = u.id WHERE d.dish_id = '$dishId'");
    if (mysqli_num_rows($dish_q) > 0) {
        $selected_dish = mysqli_fetch_assoc($dish_q);
        $show_checkout = true;
    }
}

include 'includes/header.php';
?>

<div class="dashboard-grid">
    <!-- Sidebar Navigation -->
    <aside class="sidebar">
        <div class="sidebar-profile">
            <div class="profile-avatar">
                <?php echo strtoupper(substr(getUserName(), 0, 1)); ?>
            </div>
            <h3><?php echo htmlspecialchars(getUserName()); ?></h3>
            <span class="profile-role"><?php echo $role; ?></span>
        </div>
        <ul class="sidebar-menu">
            <li><a href="dashboard.php" class="sidebar-menu-link"><i class='bx bx-grid-alt'></i> Dashboard</a></li>
            <?php if ($role == 'customer'): ?>
                <li><a href="dishes.php" class="sidebar-menu-link"><i class='bx bx-dish'></i> Browse Dishes</a></li>
                <li><a href="order.php" class="sidebar-menu-link active"><i class='bx bx-receipt'></i> My Orders</a></li>
                <li><a href="booking.php" class="sidebar-menu-link"><i class='bx bx-calendar'></i> Book Chef</a></li>
                <li><a href="membership.php" class="sidebar-menu-link"><i class='bx bx-crown'></i> Royal Club</a></li>
                <li><a href="review.php" class="sidebar-menu-link"><i class='bx bx-star'></i> Give Review</a></li>
            <?php elseif ($role == 'chef'): ?>
                <li><a href="dishes.php" class="sidebar-menu-link"><i class='bx bx-plus-circle'></i> Manage Dishes</a></li>
                <li><a href="order.php" class="sidebar-menu-link active"><i class='bx bx-list-check'></i> Orders Received</a></li>
                <li><a href="booking.php" class="sidebar-menu-link"><i class='bx bx-calendar-event'></i> Bookings Schedule</a></li>
                <li><a href="review.php" class="sidebar-menu-link"><i class='bx bx-message-square-detail'></i> Reviews Received</a></li>
            <?php elseif ($role == 'admin'): ?>
                <li><a href="order.php" class="sidebar-menu-link active"><i class='bx bx-receipt'></i> Manage Orders</a></li>
                <li><a href="membership.php" class="sidebar-menu-link"><i class='bx bx-crown'></i> Memberships</a></li>
            <?php endif; ?>
        </ul>
    </aside>

    <!-- Main Content Area -->
    <section class="dashboard-main">
        <?php if (!empty($error)): ?><div class="alert alert-danger"><?php echo $error; ?></div><?php endif; ?>
        <?php if (!empty($success)): ?><div class="alert alert-success"><?php echo $success; ?></div><?php endif; ?>

        <?php if ($show_checkout): ?>
            <!-- Checkout Form for Customer -->
            <div class="table-panel" style="max-width: 600px; margin: 0 auto;">
                <h2>Confirm Your Order</h2>
                <div style="margin: 20px 0; padding: 15px; background: rgba(255, 124, 59, 0.05); border-radius: var(--radius-md); border: 1px solid var(--border-color);">
                    <h3 style="color: var(--brand-primary);"><?php echo htmlspecialchars($selected_dish['dish_name']); ?></h3>
                    <p style="color: var(--text-secondary); margin: 8px 0;"><?php echo htmlspecialchars($selected_dish['description']); ?></p>
                    <p style="font-size: 0.9rem; color: var(--text-muted);">Chef: <?php echo htmlspecialchars($selected_dish['chef_name']); ?></p>
                </div>

                <form action="order.php" method="POST">
                    <input type="hidden" name="dish_id" value="<?php echo $selected_dish['dish_id']; ?>">
                    
                    <div class="form-group">
                        <label for="order-quantity">Quantity</label>
                        <input type="number" name="quantity" id="order-quantity" class="form-control" value="1" min="1" max="20" required>
                    </div>

                    <div style="display: flex; justify-content: space-between; align-items: center; margin: 24px 0; border-top: 1px solid var(--border-color); padding-top: 20px;">
                        <div>
                            <span style="font-size: 0.9rem; color: var(--text-muted);">Unit Price: </span>
                            <span id="dish-unit-price" style="font-weight: 600;">$<?php echo number_format($selected_dish['price'], 2); ?></span>
                        </div>
                        <div>
                            <span style="font-size: 1.1rem; font-weight: 600;">Total Estimate: </span>
                            <span id="order-total-price" style="font-size: 1.8rem; font-weight: 800; color: var(--brand-primary);">$<?php echo number_format($selected_dish['price'], 2); ?></span>
                        </div>
                    </div>

                    <button type="submit" name="place_order" class="btn btn-primary" style="width: 100%;">Place Order</button>
                    <a href="dishes.php" class="btn btn-secondary" style="width: 100%; margin-top: 10px;">Cancel</a>
                </form>
            </div>

        <?php else: ?>
            <!-- Normal Order History / Management lists -->
            <div>
                <h2><?php 
                    echo ($role == 'customer') ? 'Order History' : (($role == 'chef') ? 'Orders Received' : 'Global Order Management'); 
                ?></h2>
                <p style="color: var(--text-secondary);">Manage and monitor food orders.</p>
            </div>

            <div class="table-panel">
                <div class="table-responsive">
                    <table class="data-table">
                        <thead>
                            <tr>
                                <th>Order ID</th>
                                <th>Dish Name</th>
                                <th><?php echo ($role == 'chef') ? 'Customer' : (($role == 'customer') ? 'Chef' : 'Customer & Chef'); ?></th>
                                <th>Qty</th>
                                <th>Total</th>
                                <th>Date</th>
                                <th>Status</th>
                                <?php if ($role == 'chef' || $role == 'admin'): ?>
                                    <th style="text-align: right;">Action</th>
                                <?php endif; ?>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if ($orders && mysqli_num_rows($orders) > 0): ?>
                                <?php while ($row = mysqli_fetch_assoc($orders)): ?>
                                    <tr>
                                        <td>#<?php echo $row['order_id']; ?></td>
                                        <td><strong><?php echo htmlspecialchars($row['dish_name']); ?></strong></td>
                                        <td><?php 
                                            if ($role == 'customer') {
                                                echo htmlspecialchars($row['chef_name']);
                                            } elseif ($role == 'chef') {
                                                echo htmlspecialchars($row['customer_name']);
                                            } else {
                                                echo "<small>Cust: " . htmlspecialchars($row['customer_name']) . "<br>Chef: " . htmlspecialchars($row['chef_name']) . "</small>";
                                            }
                                        ?></td>
                                        <td><?php echo $row['quantity']; ?></td>
                                        <td style="color: var(--brand-primary); font-weight: 600;">$<?php echo number_format($row['total_price'], 2); ?></td>
                                        <td style="font-size: 0.82rem; color: var(--text-secondary);"><?php echo date('M d, Y h:i A', strtotime($row['order_date'])); ?></td>
                                        <td>
                                            <span class="badge badge-<?php 
                                                echo ($row['status'] == 'Completed') ? 'success' : (($row['status'] == 'Pending') ? 'pending' : (($row['status'] == 'Cancelled') ? 'danger' : 'info')); 
                                            ?>"><?php echo htmlspecialchars($row['status']); ?></span>
                                        </td>
                                        <?php if ($role == 'chef' || $role == 'admin'): ?>
                                            <td style="text-align: right;">
                                                <form action="order.php" method="POST" style="display: inline-flex; gap: 6px;">
                                                    <input type="hidden" name="order_id" value="<?php echo $row['order_id']; ?>">
                                                    
                                                    <?php if ($row['status'] == 'Pending'): ?>
                                                        <input type="hidden" name="new_status" value="Preparing">
                                                        <button type="submit" name="update_status" class="btn btn-primary btn-sm">Accept</button>
                                                    <?php elseif ($row['status'] == 'Preparing'): ?>
                                                        <input type="hidden" name="new_status" value="Completed">
                                                        <button type="submit" name="update_status" class="btn btn-primary btn-sm" style="background: var(--success);">Complete</button>
                                                    <?php endif; ?>

                                                    <?php if ($row['status'] != 'Completed' && $row['status'] != 'Cancelled'): ?>
                                                        <form action="order.php" method="POST">
                                                            <input type="hidden" name="order_id" value="<?php echo $row['order_id']; ?>">
                                                            <input type="hidden" name="new_status" value="Cancelled">
                                                            <button type="submit" name="update_status" class="btn btn-danger btn-sm">Cancel</button>
                                                        </form>
                                                    <?php endif; ?>
                                                </form>
                                            </td>
                                        <?php endif; ?>
                                    </tr>
                                <?php endwhile; ?>
                            <?php else: ?>
                                <tr><td colspan="8" style="text-align: center;">No orders found.</td></tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        <?php endif; ?>
    </section>
</div>

<?php include 'includes/footer.php'; ?>
