<?php
require_once 'includes/config.php';
requireLogin();

$userId = getUserId();
$role = getUserRole();

$error = '';
$success = '';

// Handle actions (Chef status change)
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['update_booking_status'])) {
        $bookingId = intval($_POST['booking_id']);
        $newStatus = sanitize($_POST['new_status']);
        $chefId = getChefId($userId);

        if ($role == 'chef') {
            // Verify chef ownership
            $check_q = mysqli_query($conn, "SELECT booking_id FROM bookings WHERE booking_id = '$bookingId' AND chef_id = '$chefId'");
            if (mysqli_num_rows($check_q) > 0) {
                $update_q = "UPDATE bookings SET status = '$newStatus' WHERE booking_id = '$bookingId'";
                if (mysqli_query($conn, $update_q)) {
                    $success = "Booking request status updated to $newStatus.";
                } else {
                    $error = "Failed to update booking status.";
                }
            } else {
                $error = "Unauthorized modification attempt.";
            }
        }
    }

    // Handle Customer Booking Chef
    if (isset($_POST['book_chef'])) {
        $chefId = intval($_POST['chef_id']);
        $bookingDate = sanitize($_POST['booking_date']);

        if (empty($bookingDate)) {
            $error = "Please choose a booking date.";
        } else {
            // Check if booking date is in the future
            if (strtotime($bookingDate) < time()) {
                $error = "Booking date must be in the future.";
            } else {
                $insert_q = "INSERT INTO bookings (customer_id, chef_id, booking_date, status) VALUES ('$userId', '$chefId', '$bookingDate', 'Pending')";
                if (mysqli_query($conn, $insert_q)) {
                    $success = "Booking request submitted successfully. Waiting for Chef confirmation.";
                } else {
                    $error = "Failed to submit booking request.";
                }
            }
        }
    }
}

// Fetch lists
$bookings = [];
$chefs = [];

if ($conn) {
    if ($role == 'customer') {
        // Fetch existing bookings
        $book_q = "SELECT b.*, u.name as chef_name, c.speciality 
                   FROM bookings b 
                   JOIN chefs c ON b.chef_id = c.chef_id 
                   JOIN users u ON c.user_id = u.id 
                   WHERE b.customer_id = '$userId' 
                   ORDER BY b.booking_id DESC";
        $bookings = mysqli_query($conn, $book_q);

        // Fetch list of available chefs
        $chef_list_q = "SELECT c.chef_id, u.name, c.speciality, c.experience 
                        FROM chefs c 
                        JOIN users u ON c.user_id = u.id";
        $chefs = mysqli_query($conn, $chef_list_q);

    } elseif ($role == 'chef') {
        $chefId = getChefId($userId);
        $book_q = "SELECT b.*, u.name as customer_name 
                   FROM bookings b 
                   JOIN users u ON b.customer_id = u.id 
                   WHERE b.chef_id = '$chefId' 
                   ORDER BY b.booking_id DESC";
        $bookings = mysqli_query($conn, $book_q);
    }
}

include 'includes/header.php';
?>

<div class="dashboard-grid">
    <!-- Sidebar Navigation -->
    <aside class="sidebar">
        <div class="sidebar-profile">
            <div class="profile-avatar">
                <?php echo strtoupper(substr(getUserName(), 0, 1)); ?>
            </div>
            <h3><?php echo htmlspecialchars(getUserName()); ?></h3>
            <span class="profile-role"><?php echo $role; ?></span>
        </div>
        <ul class="sidebar-menu">
            <li><a href="dashboard.php" class="sidebar-menu-link"><i class='bx bx-grid-alt'></i> Dashboard</a></li>
            <?php if ($role == 'customer'): ?>
                <li><a href="dishes.php" class="sidebar-menu-link"><i class='bx bx-dish'></i> Browse Dishes</a></li>
                <li><a href="order.php" class="sidebar-menu-link"><i class='bx bx-receipt'></i> My Orders</a></li>
                <li><a href="booking.php" class="sidebar-menu-link active"><i class='bx bx-calendar'></i> Book Chef</a></li>
                <li><a href="membership.php" class="sidebar-menu-link"><i class='bx bx-crown'></i> Royal Club</a></li>
                <li><a href="review.php" class="sidebar-menu-link"><i class='bx bx-star'></i> Give Review</a></li>
            <?php elseif ($role == 'chef'): ?>
                <li><a href="dishes.php" class="sidebar-menu-link"><i class='bx bx-plus-circle'></i> Manage Dishes</a></li>
                <li><a href="order.php" class="sidebar-menu-link"><i class='bx bx-list-check'></i> Orders Received</a></li>
                <li><a href="booking.php" class="sidebar-menu-link active"><i class='bx bx-calendar-event'></i> Bookings Schedule</a></li>
                <li><a href="review.php" class="sidebar-menu-link"><i class='bx bx-message-square-detail'></i> Reviews Received</a></li>
            <?php endif; ?>
        </ul>
    </aside>

    <!-- Main Content Area -->
    <section class="dashboard-main">
        <div>
            <h2>Chef Bookings Schedule</h2>
            <p style="color: var(--text-secondary);"><?php echo ($role == 'chef') ? 'Accept or reject booking offers for private dining sessions.' : 'Arrange a private home dining experience.'; ?></p>
        </div>

        <?php if (!empty($error)): ?><div class="alert alert-danger"><?php echo $error; ?></div><?php endif; ?>
        <?php if (!empty($success)): ?><div class="alert alert-success"><?php echo $success; ?></div><?php endif; ?>

        <?php if ($role == 'customer'): ?>
            <!-- Customer Booking Form -->
            <div class="table-panel">
                <h3>Submit Booking Request</h3>
                <form action="booking.php" method="POST" style="margin-top: 15px;">
                    <div style="display: grid; grid-template-columns: 2fr 1fr; gap: 20px;">
                        <div class="form-group">
                            <label for="chef_id">Choose a Culinary Artist</label>
                            <select name="chef_id" id="chef_id" class="form-control" required>
                                <?php if ($chefs && mysqli_num_rows($chefs) > 0): ?>
                                    <?php while ($chef = mysqli_fetch_assoc($chefs)): ?>
                                        <option value="<?php echo $chef['chef_id']; ?>">
                                            <?php echo htmlspecialchars($chef['name']); ?> (<?php echo htmlspecialchars($chef['speciality']); ?> - <?php echo $chef['experience']; ?> Yrs Exp)
                                        </option>
                                    <?php endwhile; ?>
                                <?php else: ?>
                                    <option value="">No chefs available</option>
                                <?php endif; ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="booking_date">Choose Date</label>
                            <input type="date" name="booking_date" id="booking_date" class="form-control" required>
                        </div>
                    </div>
                    <button type="submit" name="book_chef" class="btn btn-primary"><i class='bx bx-calendar-plus'></i> Send Booking Request</button>
                </form>
            </div>
        <?php endif; ?>

        <!-- List bookings -->
        <div class="table-panel">
            <h3>Reservations List</h3>
            <div class="table-responsive">
                <table class="data-table">
                    <thead>
                        <tr>
                            <th>Booking ID</th>
                            <th><?php echo ($role == 'customer') ? 'Chef' : 'Customer'; ?></th>
                            <?php if ($role == 'customer'): ?>
                                <th>Speciality</th>
                            <?php endif; ?>
                            <th>Booking Date</th>
                            <th>Status</th>
                            <?php if ($role == 'chef'): ?>
                                <th style="text-align: right;">Action</th>
                            <?php endif; ?>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if ($bookings && mysqli_num_rows($bookings) > 0): ?>
                            <?php while ($row = mysqli_fetch_assoc($bookings)): ?>
                                <tr>
                                    <td>#<?php echo $row['booking_id']; ?></td>
                                    <td><strong><?php echo htmlspecialchars(($role == 'customer') ? $row['chef_name'] : $row['customer_name']); ?></strong></td>
                                    <?php if ($role == 'customer'): ?>
                                        <td><?php echo htmlspecialchars($row['speciality']); ?></td>
                                    <?php endif; ?>
                                    <td><?php echo date('F d, Y', strtotime($row['booking_date'])); ?></td>
                                    <td>
                                        <span class="badge badge-<?php 
                                            echo ($row['status'] == 'Accepted') ? 'success' : (($row['status'] == 'Pending') ? 'pending' : 'danger'); 
                                        ?>"><?php echo htmlspecialchars($row['status']); ?></span>
                                    </td>
                                    <?php if ($role == 'chef' && $row['status'] == 'Pending'): ?>
                                        <td style="text-align: right;">
                                            <form action="booking.php" method="POST" style="display: inline-flex; gap: 6px;">
                                                <input type="hidden" name="booking_id" value="<?php echo $row['booking_id']; ?>">
                                                
                                                <button type="submit" name="update_booking_status" class="btn btn-primary btn-sm" onclick="this.form.new_status.value='Accepted';">
                                                    Accept
                                                </button>
                                                <button type="submit" name="update_booking_status" class="btn btn-danger btn-sm" onclick="this.form.new_status.value='Rejected';">
                                                    Reject
                                                </button>
                                                
                                                <input type="hidden" name="new_status" value="">
                                            </form>
                                        </td>
                                    <?php elseif ($role == 'chef'): ?>
                                        <td style="text-align: right; color: var(--text-muted); font-size: 0.85rem;">No actions</td>
                                    <?php endif; ?>
                                </tr>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <tr><td colspan="6" style="text-align: center;">No reservations scheduled.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </section>
</div>

<?php include 'includes/footer.php'; ?>
