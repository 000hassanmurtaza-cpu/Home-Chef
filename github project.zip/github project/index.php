<?php
include 'includes/header.php';

// Fetch some dishes from database if tables exist
$dishes = [];
$chefs = [];

if ($conn) {
    // Check if table dishes exists and fetch 3 dishes
    $dish_query = "SELECT d.*, c.speciality, u.name as chef_name 
                   FROM dishes d 
                   JOIN chefs c ON d.chef_id = c.chef_id 
                   JOIN users u ON c.user_id = u.id 
                   LIMIT 3";
    $dish_result = mysqli_query($conn, $dish_query);
    if ($dish_result) {
        while ($row = mysqli_fetch_assoc($dish_result)) {
            $dishes[] = $row;
        }
    }

    // Fetch Chefs
    $chef_query = "SELECT c.*, u.name as chef_name FROM chefs c JOIN users u ON c.user_id = u.id LIMIT 2";
    $chef_result = mysqli_query($conn, $chef_query);
    if ($chef_result) {
        while ($row = mysqli_fetch_assoc($chef_result)) {
            $chefs[] = $row;
        }
    }
}
?>

<!-- Hero Section -->
<section class="hero">
    <div class="hero-content">
        <span class="hero-tagline">Connecting Gourmets with Culinary Artists</span>
        <h1>Experience Restaurant Quality at <span>Home</span></h1>
        <p class="hero-description">Browse talented home-based chefs, order delicious custom-cooked meals, book direct private dinners, and join our Royal Club.</p>
        <div class="hero-buttons">
            <?php if (isLoggedIn()): ?>
                <a href="dashboard.php" class="btn btn-primary">Go to Dashboard</a>
                <a href="dishes.php" class="btn btn-secondary">Browse Dishes</a>
            <?php else: ?>
                <a href="register.php" class="btn btn-primary">Get Started</a>
                <a href="login.php" class="btn btn-secondary">Sign In</a>
            <?php endif; ?>
        </div>
    </div>
</section>

<!-- Features section -->
<section class="py-5">
    <div class="section-title">
        <h2>Our Main Features</h2>
        <p>A comprehensive system designed for food lovers and culinary professionals.</p>
    </div>
    <div class="features-grid">
        <div class="feature-card">
            <div class="feature-icon"><i class='bx bx-dish'></i></div>
            <h3>Smart Food Ordering</h3>
            <p>Order custom-prepared meals made by professional chefs using local ingredients. Fresh, healthy, and tailored to you.</p>
        </div>
        <div class="feature-card">
            <div class="feature-icon"><i class='bx bx-calendar-star'></i></div>
            <h3>Chef Booking System</h3>
            <p>Schedule a chef to come to your home, plan a menu, and prepare hot, delicious meals for private events or family gatherings.</p>
        </div>
        <div class="feature-card">
            <div class="feature-icon"><i class='bx bx-crown'></i></div>
            <h3>Royal Club Membership</h3>
            <p>Subscribe to premium tiers to unlock free deliveries, exclusive discounts, and early booking opportunities with top chefs.</p>
        </div>
    </div>
</section>

<!-- Database-Driven Section: Dishes -->
<?php if (!empty($dishes)): ?>
<section class="py-5" style="border-top: 1px solid var(--border-color); padding-top: 60px;">
    <div class="section-title">
        <h2>Popular Dishes</h2>
        <p>Order fresh culinary creations directly from home kitchens.</p>
    </div>
    <div class="card-grid">
        <?php foreach ($dishes as $dish): ?>
            <div class="chef-dish-card">
                <div class="card-header-pic">
                    <span class="card-tag"><?php echo htmlspecialchars($dish['speciality']); ?></span>
                    <i class='bx bx-bowl-rice' style="font-size: 4.5rem; color: var(--brand-primary); opacity: 0.8;"></i>
                </div>
                <div class="card-body">
                    <div class="card-title-price">
                        <h3><?php echo htmlspecialchars($dish['dish_name']); ?></h3>
                        <span class="card-price">$<?php echo number_format($dish['price'], 2); ?></span>
                    </div>
                    <p class="card-desc"><?php echo htmlspecialchars($dish['description']); ?></p>
                    <div class="card-meta">
                        <span>By <?php echo htmlspecialchars($dish['chef_name']); ?></span>
                        <a href="dishes.php" class="btn btn-primary btn-sm">Order Now</a>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
</section>
<?php endif; ?>

<!-- Testimonials / Review Highlights -->
<section class="py-5" style="border-top: 1px solid var(--border-color); padding-top: 60px; margin-bottom: 40px;">
    <div class="section-title">
        <h2>What Our Customers Say</h2>
        <p>Real feedback from members of the Home Chef marketplace community.</p>
    </div>
    <div class="reviews-grid">
        <div class="review-bubble">
            <div class="review-stars">
                <i class='bx bxs-star'></i><i class='bx bxs-star'></i><i class='bx bxs-star'></i><i class='bx bxs-star'></i><i class='bx bxs-star'></i>
            </div>
            <p class="review-comment">"The Beef Wellington was to die for! The pastry stayed perfectly crisp, and booking Chef Gordon for my anniversary dinner was the best decision ever."</p>
            <div class="review-author">
                <span class="review-author-name">John Doe</span>
                <span>Royal Gold Member</span>
            </div>
        </div>
        <div class="review-bubble">
            <div class="review-stars">
                <i class='bx bxs-star'></i><i class='bx bxs-star'></i><i class='bx bxs-star'></i><i class='bx bxs-star'></i><i class='bx bx-star'></i>
            </div>
            <p class="review-comment">"Fresh sourdough artisan bread delivered straight to my door. Great interface and very easy to manage my weekly subscriptions."</p>
            <div class="review-author">
                <span class="review-author-name">Jane Smith</span>
                <span>Regular Customer</span>
            </div>
        </div>
    </div>
</section>

<?php include 'includes/footer.php'; ?>
