<?php
require_once __DIR__ . '/config.php';
$current_page = basename($_SERVER['PHP_SELF']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home Chef - Premium Database Management System</title>
    <link rel="stylesheet" href="css/style.css">
    <!-- Boxicons for modern icons -->
    <link href="https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css" rel="stylesheet">
</head>
<body>

<header class="site-header">
    <div class="container navbar">
        <a href="index.php" class="logo">
            <i class='bx bx-restaurant'></i> Home<span>Chef</span>
        </a>
        <nav>
            <ul class="nav-links">
                <li><a href="index.php" class="nav-link <?php echo $current_page == 'index.php' ? 'active' : ''; ?>">Home</a></li>
                
                <?php if (isLoggedIn()): ?>
                    <li><a href="dashboard.php" class="nav-link <?php echo $current_page == 'dashboard.php' ? 'active' : ''; ?>">Dashboard</a></li>
                    
                    <?php if (getUserRole() == 'customer'): ?>
                        <li><a href="dishes.php" class="nav-link <?php echo $current_page == 'dishes.php' ? 'active' : ''; ?>">Dishes</a></li>
                        <li><a href="booking.php" class="nav-link <?php echo $current_page == 'booking.php' ? 'active' : ''; ?>">Book Chef</a></li>
                        <li><a href="membership.php" class="nav-link <?php echo $current_page == 'membership.php' ? 'active' : ''; ?>">Royal Club</a></li>
                        <li><a href="review.php" class="nav-link <?php echo $current_page == 'review.php' ? 'active' : ''; ?>">Reviews</a></li>
                    <?php elseif (getUserRole() == 'chef'): ?>
                        <li><a href="dishes.php" class="nav-link <?php echo $current_page == 'dishes.php' ? 'active' : ''; ?>">My Dishes</a></li>
                        <li><a href="order.php" class="nav-link <?php echo $current_page == 'order.php' ? 'active' : ''; ?>">Chef Orders</a></li>
                        <li><a href="booking.php" class="nav-link <?php echo $current_page == 'booking.php' ? 'active' : ''; ?>">Bookings</a></li>
                        <li><a href="review.php" class="nav-link <?php echo $current_page == 'review.php' ? 'active' : ''; ?>">Reviews</a></li>
                    <?php elseif (getUserRole() == 'admin'): ?>
                        <li><a href="order.php" class="nav-link <?php echo $current_page == 'order.php' ? 'active' : ''; ?>">All Orders</a></li>
                        <li><a href="membership.php" class="nav-link <?php echo $current_page == 'membership.php' ? 'active' : ''; ?>">Memberships</a></li>
                    <?php endif; ?>

                    <li><a href="logout.php" class="nav-link btn-nav-action"><i class='bx bx-log-out'></i> Logout</a></li>
                <?php else: ?>
                    <li><a href="login.php" class="nav-link <?php echo $current_page == 'login.php' ? 'active' : ''; ?>">Login</a></li>
                    <li><a href="register.php" class="btn-nav-action">Join Free</a></li>
                <?php endif; ?>
            </ul>
        </nav>
    </div>
</header>

<main class="main-content container py-4">
<?php displayFlashMessages(); ?>
