</main>

<footer class="site-footer">
    <div class="container footer-content">
        <div class="footer-logo">
            <i class='bx bx-restaurant'></i> HomeChef
        </div>
        <p>&copy; <?php echo date('Y'); ?> Home Chef DBMS. Built for University Project Submission.</p>
        <div>
            <a href="#" style="margin-right: 15px;">Privacy Policy</a>
            <a href="#">Terms of Service</a>
        </div>
    </div>
</footer>

<script src="js/script.js"></script>
</body>
</html>
