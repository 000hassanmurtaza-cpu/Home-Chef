<?php
// PHP session initiation
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Database config configuration
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'home_chef');

// Database Connection
$conn = mysqli_connect(DB_HOST, DB_USER, DB_PASS, DB_NAME);

if (!$conn) {
    die("Database Connection failed: " . mysqli_connect_error());
}

// Helper: Sanitize inputs to prevent SQLi & XSS
function sanitize($data) {
    global $conn;
    return mysqli_real_escape_string($conn, htmlspecialchars(strip_tags(trim($data))));
}

// Helper: Check authentication
function isLoggedIn() {
    return isset($_SESSION['user_id']);
}

// Helper: Get user details
function getUserId() {
    return $_SESSION['user_id'] ?? null;
}

function getUserName() {
    return $_SESSION['user_name'] ?? '';
}

function getUserRole() {
    return $_SESSION['user_role'] ?? '';
}

// Helper: Force authentication
function requireLogin() {
    if (!isLoggedIn()) {
        $_SESSION['flash_error'] = "You must be logged in to view this page.";
        header("Location: login.php");
        exit();
    }
}

// Helper: Check specific roles
function requireRole($allowedRoles) {
    requireLogin();
    $role = getUserRole();
    if (is_string($allowedRoles)) {
        $allowedRoles = [$allowedRoles];
    }
    if (!in_array($role, $allowedRoles)) {
        $_SESSION['flash_error'] = "Access denied: Unauthorized access attempt.";
        header("Location: dashboard.php");
        exit();
    }
}

// Helper: Display Alert messages
function displayFlashMessages() {
    if (isset($_SESSION['flash_success'])) {
        echo '<div class="alert alert-success">' . $_SESSION['flash_success'] . '</div>';
        unset($_SESSION['flash_success']);
    }
    if (isset($_SESSION['flash_error'])) {
        echo '<div class="alert alert-danger">' . $_SESSION['flash_error'] . '</div>';
        unset($_SESSION['flash_error']);
    }
}

// Helper: Check Chef ID of logged in user
function getChefId($userId) {
    global $conn;
    $sql = "SELECT chef_id FROM chefs WHERE user_id = '$userId'";
    $result = mysqli_query($conn, $sql);
    if ($result && mysqli_num_rows($result) > 0) {
        $row = mysqli_fetch_assoc($result);
        return $row['chef_id'];
    }
    return null;
}
?>
