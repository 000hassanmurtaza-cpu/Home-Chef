-- Create Database if not exists
CREATE DATABASE IF NOT EXISTS home_chef;
USE home_chef;

-- Drop tables if they exist (to clean up before re-importing)
DROP TABLE IF EXISTS reviews;
DROP TABLE IF EXISTS bookings;
DROP TABLE IF EXISTS orders;
DROP TABLE IF EXISTS membership;
DROP TABLE IF EXISTS dishes;
DROP TABLE IF EXISTS chefs;
DROP TABLE IF EXISTS users;

-- 1. Users Table
CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    role ENUM('customer', 'chef', 'admin') NOT NULL
) ENGINE=InnoDB;

-- 2. Chefs Table
CREATE TABLE chefs (
    chef_id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    speciality VARCHAR(100) NOT NULL,
    experience INT NOT NULL,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- 3. Dishes Table
CREATE TABLE dishes (
    dish_id INT AUTO_INCREMENT PRIMARY KEY,
    chef_id INT NOT NULL,
    dish_name VARCHAR(100) NOT NULL,
    price DECIMAL(10,2) NOT NULL,
    description TEXT,
    FOREIGN KEY (chef_id) REFERENCES chefs(chef_id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- 4. Orders Table
CREATE TABLE orders (
    order_id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    dish_id INT NOT NULL,
    quantity INT NOT NULL,
    total_price DECIMAL(10,2) NOT NULL,
    status VARCHAR(50) DEFAULT 'Pending',
    order_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (dish_id) REFERENCES dishes(dish_id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- 5. Bookings Table
CREATE TABLE bookings (
    booking_id INT AUTO_INCREMENT PRIMARY KEY,
    customer_id INT NOT NULL,
    chef_id INT NOT NULL,
    booking_date DATE NOT NULL,
    status VARCHAR(50) DEFAULT 'Pending',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (customer_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (chef_id) REFERENCES chefs(chef_id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- 6. Membership Table
CREATE TABLE membership (
    membership_id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    plan_name VARCHAR(50) NOT NULL,
    price DECIMAL(10,2) NOT NULL,
    status VARCHAR(20) DEFAULT 'Active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- 7. Reviews Table
CREATE TABLE reviews (
    review_id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    chef_id INT NOT NULL,
    rating INT NOT NULL CHECK (rating BETWEEN 1 AND 5),
    comment TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (chef_id) REFERENCES chefs(chef_id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- Populate Mock Data
-- Passwords are all md5 or password_hash of 'password123'
-- Hash of 'password123': $2y$10$T8Z65vCpl87p.c6wPq9l3uQ4oR8E1V.uE72Zq5PZgC23q4YVpA7yq (or let's use plain md5 if preferred, but standard PHP password_hash is better. We will use password_hash. Let's use the standard hash for password123: $2y$10$yFfM6wX.J2fQG21LgCg7N.b.Fj2Lw7U3m69j3H0tI4lR1T0/y6/W2)
-- To keep things simple and fully compatible, let's use standard password_hash.

INSERT INTO users (id, name, email, password, role) VALUES
(1, 'Admin User', 'admin@homechef.com', '$2y$10$yFfM6wX.J2fQG21LgCg7N.b.Fj2Lw7U3m69j3H0tI4lR1T0/y6/W2', 'admin'),
(2, 'Chef Gordon', 'gordon@homechef.com', '$2y$10$yFfM6wX.J2fQG21LgCg7N.b.Fj2Lw7U3m69j3H0tI4lR1T0/y6/W2', 'chef'),
(3, 'Chef Julia', 'julia@homechef.com', '$2y$10$yFfM6wX.J2fQG21LgCg7N.b.Fj2Lw7U3m69j3H0tI4lR1T0/y6/W2', 'chef'),
(4, 'John Doe', 'john@gmail.com', '$2y$10$yFfM6wX.J2fQG21LgCg7N.b.Fj2Lw7U3m69j3H0tI4lR1T0/y6/W2', 'customer'),
(5, 'Jane Smith', 'jane@gmail.com', '$2y$10$yFfM6wX.J2fQG21LgCg7N.b.Fj2Lw7U3m69j3H0tI4lR1T0/y6/W2', 'customer');

INSERT INTO chefs (chef_id, user_id, speciality, experience) VALUES
(1, 2, 'French & Italian Fine Dining', 15),
(2, 3, 'Traditional Baking & Pastries', 8);

INSERT INTO dishes (dish_id, chef_id, dish_name, price, description) VALUES
(1, 1, 'Beef Wellington', 45.00, 'Tender beef fillet wrapped in puff pastry with mushroom duxelles.'),
(2, 1, 'Truffle Risotto', 30.00, 'Creamy arborio rice infused with black truffle paste and parmesan.'),
(3, 2, 'Chocolate Soufflé', 15.00, 'Warm, airy chocolate dessert with a molten lava center.'),
(4, 2, 'Sourdough Artisan Bread', 8.50, 'Freshly baked naturally fermented sourdough loaf.');

INSERT INTO orders (order_id, user_id, dish_id, quantity, total_price, status) VALUES
(1, 4, 1, 2, 90.00, 'Completed'),
(2, 4, 3, 1, 15.00, 'Pending'),
(3, 5, 2, 1, 30.00, 'Preparing');

INSERT INTO bookings (booking_id, customer_id, chef_id, booking_date, status) VALUES
(1, 4, 1, '2026-06-15', 'Accepted'),
(2, 5, 2, '2026-06-20', 'Pending');

INSERT INTO membership (membership_id, user_id, plan_name, price, status) VALUES
(1, 4, 'Royal Club Gold', 29.99, 'Active');

INSERT INTO reviews (review_id, user_id, chef_id, rating, comment) VALUES
(1, 4, 1, 5, 'Absolutely incredible beef wellington. The crust was perfectly crispy and the meat melted in my mouth!'),
(2, 5, 2, 4, 'Wonderful sourdough bread, very fresh and crusty.');
