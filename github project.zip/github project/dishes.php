<?php
require_once 'includes/config.php';
requireLogin();

$userId = getUserId();
$role = getUserRole();

$error = '';
$success = '';

// Handle actions if user is Chef
if ($role == 'chef') {
    $chefId = getChefId($userId);
    if (!$chefId) {
        $_SESSION['flash_error'] = "Chef profile not found.";
        header("Location: dashboard.php");
        exit();
    }

    // Add Dish Action
    if (isset($_POST['add_dish'])) {
        $dish_name = sanitize($_POST['dish_name']);
        $price = floatval($_POST['price']);
        $description = sanitize($_POST['description']);

        if (empty($dish_name) || $price <= 0) {
            $error = "Please enter a valid dish name and price.";
        } else {
            $insert_q = "INSERT INTO dishes (chef_id, dish_name, price, description) VALUES ('$chefId', '$dish_name', '$price', '$description')";
            if (mysqli_query($conn, $insert_q)) {
                $success = "Dish added successfully!";
            } else {
                $error = "Failed to add dish.";
            }
        }
    }

    // Delete Dish Action
    if (isset($_GET['delete_id'])) {
        $deleteId = intval($_GET['delete_id']);
        // Verify ownership
        $check_q = mysqli_query($conn, "SELECT dish_id FROM dishes WHERE dish_id = '$deleteId' AND chef_id = '$chefId'");
        if (mysqli_num_rows($check_q) > 0) {
            $delete_q = "DELETE FROM dishes WHERE dish_id = '$deleteId'";
            if (mysqli_query($conn, $delete_q)) {
                $success = "Dish deleted successfully!";
            } else {
                $error = "Failed to delete dish.";
            }
        } else {
            $error = "Unauthorized deletion attempt.";
        }
    }

    // Fetch Chef's dishes
    $dishes_result = mysqli_query($conn, "SELECT * FROM dishes WHERE chef_id = '$chefId' ORDER BY dish_id DESC");

} else {
    // Customer browsing all dishes
    $dishes_q = "SELECT d.*, c.speciality, u.name as chef_name 
                 FROM dishes d 
                 JOIN chefs c ON d.chef_id = c.chef_id 
                 JOIN users u ON c.user_id = u.id 
                 ORDER BY d.dish_id DESC";
    $dishes_result = mysqli_query($conn, $dishes_q);
}

include 'includes/header.php';
?>

<div class="dashboard-grid">
    <!-- Sidebar Navigation -->
    <aside class="sidebar">
        <div class="sidebar-profile">
            <div class="profile-avatar">
                <?php echo strtoupper(substr(getUserName(), 0, 1)); ?>
            </div>
            <h3><?php echo htmlspecialchars(getUserName()); ?></h3>
            <span class="profile-role"><?php echo $role; ?></span>
        </div>
        <ul class="sidebar-menu">
            <li><a href="dashboard.php" class="sidebar-menu-link"><i class='bx bx-grid-alt'></i> Dashboard</a></li>
            <?php if ($role == 'customer'): ?>
                <li><a href="dishes.php" class="sidebar-menu-link active"><i class='bx bx-dish'></i> Browse Dishes</a></li>
                <li><a href="order.php" class="sidebar-menu-link"><i class='bx bx-receipt'></i> My Orders</a></li>
                <li><a href="booking.php" class="sidebar-menu-link"><i class='bx bx-calendar'></i> Book Chef</a></li>
                <li><a href="membership.php" class="sidebar-menu-link"><i class='bx bx-crown'></i> Royal Club</a></li>
                <li><a href="review.php" class="sidebar-menu-link"><i class='bx bx-star'></i> Give Review</a></li>
            <?php elseif ($role == 'chef'): ?>
                <li><a href="dishes.php" class="sidebar-menu-link active"><i class='bx bx-plus-circle'></i> Manage Dishes</a></li>
                <li><a href="order.php" class="sidebar-menu-link"><i class='bx bx-list-check'></i> Orders Received</a></li>
                <li><a href="booking.php" class="sidebar-menu-link"><i class='bx bx-calendar-event'></i> Bookings Schedule</a></li>
                <li><a href="review.php" class="sidebar-menu-link"><i class='bx bx-message-square-detail'></i> Reviews Received</a></li>
            <?php endif; ?>
        </ul>
    </aside>

    <!-- Main Content Area -->
    <section class="dashboard-main">
        <div>
            <h2><?php echo ($role == 'chef') ? 'Manage Your Menu' : 'Browse Fresh Dishes'; ?></h2>
            <p style="color: var(--text-secondary);"><?php echo ($role == 'chef') ? 'Manage dishes that customers can order.' : 'Choose your favorite home-cooked meal.'; ?></p>
        </div>

        <?php if (!empty($error)): ?><div class="alert alert-danger"><?php echo $error; ?></div><?php endif; ?>
        <?php if (!empty($success)): ?><div class="alert alert-success"><?php echo $success; ?></div><?php endif; ?>

        <?php if ($role == 'chef'): ?>
            <!-- Add New Dish Form -->
            <div class="table-panel">
                <h3>Add New Dish</h3>
                <form action="dishes.php" method="POST" style="margin-top: 15px;">
                    <div style="display: grid; grid-template-columns: 2fr 1fr; gap: 20px;">
                        <div class="form-group">
                            <label for="dish_name">Dish Name</label>
                            <input type="text" name="dish_name" id="dish_name" class="form-control" placeholder="Beef Bourguignon" required>
                        </div>
                        <div class="form-group">
                            <label for="price">Price ($)</label>
                            <input type="number" name="price" id="price" class="form-control" step="0.01" min="0.50" placeholder="18.50" required>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="description">Dish Description</label>
                        <textarea name="description" id="description" class="form-control" rows="3" placeholder="Slow-cooked beef in rich red wine sauce with baby carrots..." required></textarea>
                    </div>
                    <button type="submit" name="add_dish" class="btn btn-primary"><i class='bx bx-plus'></i> Add Dish to Menu</button>
                </form>
            </div>

            <!-- List Chef's Own Dishes -->
            <div class="table-panel">
                <h3>My Dishes</h3>
                <div class="table-responsive">
                    <table class="data-table">
                        <thead>
                            <tr>
                                <th>Name</th>
                                <th>Price</th>
                                <th>Description</th>
                                <th style="text-align: right;">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (mysqli_num_rows($dishes_result) > 0): ?>
                                <?php while ($dish = mysqli_fetch_assoc($dishes_result)): ?>
                                    <tr>
                                        <td><strong><?php echo htmlspecialchars($dish['dish_name']); ?></strong></td>
                                        <td style="color: var(--brand-primary); font-weight: 600;">$<?php echo number_format($dish['price'], 2); ?></td>
                                        <td style="max-width: 300px; color: var(--text-secondary);"><?php echo htmlspecialchars($dish['description']); ?></td>
                                        <td style="text-align: right;">
                                            <a href="dishes.php?delete_id=<?php echo $dish['dish_id']; ?>" 
                                               class="btn btn-danger btn-sm btn-confirm-delete"
                                               data-msg="Are you sure you want to remove <?php echo htmlspecialchars($dish['dish_name']); ?> from your menu?">
                                               <i class='bx bx-trash'></i> Delete
                                            </a>
                                        </td>
                                    </tr>
                                <?php endwhile; ?>
                            <?php else: ?>
                                <tr><td colspan="4" style="text-align: center;">No dishes on your menu. Use the form above to add your first dish!</td></tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>

        <?php else: ?>
            <!-- Customer Browse Dishes -->
            <div class="card-grid">
                <?php if (mysqli_num_rows($dishes_result) > 0): ?>
                    <?php while ($dish = mysqli_fetch_assoc($dishes_result)): ?>
                        <div class="chef-dish-card">
                            <div class="card-header-pic">
                                <span class="card-tag"><?php echo htmlspecialchars($dish['speciality']); ?></span>
                                <i class='bx bx-bowl-rice' style="font-size: 4.5rem; color: var(--brand-primary); opacity: 0.8;"></i>
                            </div>
                            <div class="card-body">
                                <div class="card-title-price">
                                    <h3><?php echo htmlspecialchars($dish['dish_name']); ?></h3>
                                    <span class="card-price">$<?php echo number_format($dish['price'], 2); ?></span>
                                </div>
                                <p class="card-desc"><?php echo htmlspecialchars($dish['description']); ?></p>
                                <div class="card-meta">
                                    <span>Chef: <strong><?php echo htmlspecialchars($dish['chef_name']); ?></strong></span>
                                    <a href="order.php?dish_id=<?php echo $dish['dish_id']; ?>" class="btn btn-primary btn-sm"><i class='bx bx-cart'></i> Order Now</a>
                                </div>
                            </div>
                        </div>
                    <?php endwhile; ?>
                <?php else: ?>
                    <p style="text-align: center; grid-column: 1/-1;">No dishes available in the database at the moment.</p>
                <?php endif; ?>
            </div>
        <?php endif; ?>
    </section>
</div>

<?php include 'includes/footer.php'; ?>
