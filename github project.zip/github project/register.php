<?php
require_once 'includes/config.php';

// Redirect if already logged in
if (isLoggedIn()) {
    header("Location: dashboard.php");
    exit();
}

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = sanitize($_POST['name']);
    $email = sanitize($_POST['email']);
    $password = $_POST['password'];
    $role = sanitize($_POST['role']); // customer, chef
    
    // Chef fields
    $speciality = isset($_POST['speciality']) ? sanitize($_POST['speciality']) : '';
    $experience = isset($_POST['experience']) ? intval($_POST['experience']) : 0;

    if (empty($name) || empty($email) || empty($password) || empty($role)) {
        $error = "All fields are required.";
    } elseif ($role == 'chef' && (empty($speciality) || $experience <= 0)) {
        $error = "Please provide valid speciality and experience for Chef profile.";
    } else {
        // Check if email already exists
        $check_sql = "SELECT id FROM users WHERE email = '$email'";
        $check_res = mysqli_query($conn, $check_sql);
        
        if (mysqli_num_rows($check_res) > 0) {
            $error = "An account with that email already exists.";
        } else {
            // Hash password
            $hashed_pass = password_hash($password, PASSWORD_DEFAULT);
            
            // Start transaction
            mysqli_begin_transaction($conn);
            
            try {
                $user_insert = "INSERT INTO users (name, email, password, role) VALUES ('$name', '$email', '$hashed_pass', '$role')";
                if (mysqli_query($conn, $user_insert)) {
                    $user_id = mysqli_insert_id($conn);
                    
                    if ($role == 'chef') {
                        $chef_insert = "INSERT INTO chefs (user_id, speciality, experience) VALUES ('$user_id', '$speciality', '$experience')";
                        mysqli_query($conn, $chef_insert);
                    }
                    
                    mysqli_commit($conn);
                    $_SESSION['flash_success'] = "Registration successful! You can now log in.";
                    header("Location: login.php");
                    exit();
                } else {
                    throw new Exception("Error creating user account.");
                }
            } catch (Exception $e) {
                mysqli_rollback($conn);
                $error = $e->getMessage();
            }
        }
    }
}

include 'includes/header.php';
?>

<div class="auth-wrapper" style="max-width: 500px;">
    <div class="auth-header">
        <h2>Create Account</h2>
        <p>Register as a Chef or Customer</p>
    </div>

    <?php if (!empty($error)): ?>
        <div class="alert alert-danger"><?php echo $error; ?></div>
    <?php endif; ?>

    <form action="register.php" method="POST" id="reg-form">
        <div class="form-group">
            <label for="name">Full Name</label>
            <input type="text" name="name" id="name" class="form-control" placeholder="Jane Doe" required>
        </div>

        <div class="form-group">
            <label for="email">Email Address</label>
            <input type="email" name="email" id="email" class="form-control" placeholder="jane@domain.com" required>
        </div>

        <div class="form-group">
            <label for="password">Password</label>
            <input type="password" name="password" id="password" class="form-control" placeholder="••••••••" required>
        </div>

        <div class="form-group">
            <label for="role">I want to register as a:</label>
            <select name="role" id="role-select" class="form-control" required>
                <option value="customer">Customer (Order food & book chefs)</option>
                <option value="chef">Chef (Create menu & take bookings)</option>
            </select>
        </div>

        <!-- Dynamic Chef Fields (shown only if Chef is selected) -->
        <div id="chef-details-section" style="display: none; border-top: 1px solid var(--border-color); padding-top: 20px; margin-top: 20px;">
            <div class="form-group">
                <label for="speciality">Culinary Speciality</label>
                <input type="text" name="speciality" id="speciality" class="form-control" placeholder="e.g. Italian, Fine Dining, Pastries">
            </div>

            <div class="form-group">
                <label for="experience">Years of Experience</label>
                <input type="number" name="experience" id="experience" class="form-control" min="1" max="50" placeholder="e.g. 5">
            </div>
        </div>

        <button type="submit" class="btn btn-primary" style="width: 100%; margin-top: 10px;">Register</button>
    </form>

    <div style="text-align: center; margin-top: 24px; font-size: 0.9rem; color: var(--text-secondary);">
        Already have an account? <a href="login.php" style="color: var(--brand-primary); font-weight: 600;">Sign in here</a>
    </div>
</div>

<script>
document.addEventListener("DOMContentLoaded", function () {
    const roleSelect = document.getElementById("role-select");
    const chefSection = document.getElementById("chef-details-section");
    const specInput = document.getElementById("speciality");
    const expInput = document.getElementById("experience");

    roleSelect.addEventListener("change", function () {
        if (this.value === "chef") {
            chefSection.style.display = "block";
            specInput.required = true;
            expInput.required = true;
        } else {
            chefSection.style.display = "none";
            specInput.required = false;
            expInput.required = false;
        }
    });
});
</script>

<?php include 'includes/footer.php'; ?>
