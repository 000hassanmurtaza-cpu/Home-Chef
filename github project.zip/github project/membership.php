<?php
require_once 'includes/config.php';
requireLogin();

$userId = getUserId();
$role = getUserRole();

$error = '';
$success = '';

// Handle actions (Purchase/Cancel)
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['purchase_plan']) && $role == 'customer') {
        $plan = sanitize($_POST['plan_name']);
        $price = ($plan == 'Royal Club Gold') ? 29.99 : 49.99;

        // Check if already subscribed
        $check_q = mysqli_query($conn, "SELECT membership_id FROM membership WHERE user_id = '$userId' AND status = 'Active'");
        if (mysqli_num_rows($check_q) > 0) {
            $error = "You already have an active membership subscription.";
        } else {
            $insert_q = "INSERT INTO membership (user_id, plan_name, price, status) VALUES ('$userId', '$plan', '$price', 'Active')";
            if (mysqli_query($conn, $insert_q)) {
                $success = "Welcome to the $plan! Your subscription is now active.";
            } else {
                $error = "Failed to process membership subscription.";
            }
        }
    }

    if (isset($_POST['cancel_plan']) && $role == 'customer') {
        $cancel_q = "UPDATE membership SET status = 'Cancelled' WHERE user_id = '$userId' AND status = 'Active'";
        if (mysqli_query($conn, $cancel_q)) {
            $success = "Your subscription has been cancelled.";
        } else {
            $error = "Failed to cancel subscription.";
        }
    }
}

// Fetch lists
$active_plan = null;
$memberships = [];

if ($conn) {
    if ($role == 'customer') {
        // Fetch active plan
        $plan_q = mysqli_query($conn, "SELECT * FROM membership WHERE user_id = '$userId' AND status = 'Active' LIMIT 1");
        if ($plan_q && mysqli_num_rows($plan_q) > 0) {
            $active_plan = mysqli_fetch_assoc($plan_q);
        }
    } elseif ($role == 'admin') {
        // Fetch all memberships
        $all_q = "SELECT m.*, u.name as customer_name, u.email 
                  FROM membership m 
                  JOIN users u ON m.user_id = u.id 
                  ORDER BY m.membership_id DESC";
        $memberships = mysqli_query($conn, $all_q);
    }
}

include 'includes/header.php';
?>

<div class="dashboard-grid">
    <!-- Sidebar Navigation -->
    <aside class="sidebar">
        <div class="sidebar-profile">
            <div class="profile-avatar">
                <?php echo strtoupper(substr(getUserName(), 0, 1)); ?>
            </div>
            <h3><?php echo htmlspecialchars(getUserName()); ?></h3>
            <span class="profile-role"><?php echo $role; ?></span>
        </div>
        <ul class="sidebar-menu">
            <li><a href="dashboard.php" class="sidebar-menu-link"><i class='bx bx-grid-alt'></i> Dashboard</a></li>
            <?php if ($role == 'customer'): ?>
                <li><a href="dishes.php" class="sidebar-menu-link"><i class='bx bx-dish'></i> Browse Dishes</a></li>
                <li><a href="order.php" class="sidebar-menu-link"><i class='bx bx-receipt'></i> My Orders</a></li>
                <li><a href="booking.php" class="sidebar-menu-link"><i class='bx bx-calendar'></i> Book Chef</a></li>
                <li><a href="membership.php" class="sidebar-menu-link active"><i class='bx bx-crown'></i> Royal Club</a></li>
                <li><a href="review.php" class="sidebar-menu-link"><i class='bx bx-star'></i> Give Review</a></li>
            <?php elseif ($role == 'admin'): ?>
                <li><a href="order.php" class="sidebar-menu-link"><i class='bx bx-receipt'></i> Manage Orders</a></li>
                <li><a href="membership.php" class="sidebar-menu-link active"><i class='bx bx-crown'></i> Memberships</a></li>
            <?php endif; ?>
        </ul>
    </aside>

    <!-- Main Content Area -->
    <section class="dashboard-main">
        <div>
            <h2>Royal Club Membership</h2>
            <p style="color: var(--text-secondary);"><?php echo ($role == 'admin') ? 'Manage premium system subscriptions.' : 'Unlock zero-cost delivery and priority culinary access.'; ?></p>
        </div>

        <?php if (!empty($error)): ?><div class="alert alert-danger"><?php echo $error; ?></div><?php endif; ?>
        <?php if (!empty($success)): ?><div class="alert alert-success"><?php echo $success; ?></div><?php endif; ?>

        <?php if ($role == 'customer'): ?>
            <?php if ($active_plan): ?>
                <!-- Subscribed View -->
                <div class="table-panel" style="text-align: center; border-color: var(--brand-primary); padding: 50px;">
                    <div style="font-size: 4rem; color: var(--brand-primary); margin-bottom: 20px;">
                        <i class='bx bxs-crown'></i>
                    </div>
                    <h3 style="font-size: 1.8rem; margin-bottom: 8px;">Royal Club Member</h3>
                    <p style="color: var(--text-secondary); font-size: 1.05rem;">
                        You are currently subscribed to <strong><?php echo htmlspecialchars($active_plan['plan_name']); ?></strong> 
                        ($<?php echo number_format($active_plan['price'], 2); ?>/mo).
                    </p>
                    <p style="font-size: 0.85rem; color: var(--text-muted); margin-top: 10px;">
                        Subscribed on: <?php echo date('F d, Y', strtotime($active_plan['created_at'])); ?>
                    </p>
                    
                    <form action="membership.php" method="POST" style="margin-top: 30px;">
                        <button type="submit" name="cancel_plan" class="btn btn-secondary btn-sm btn-confirm-delete" 
                                data-msg="Are you sure you want to cancel your Royal Club membership?">
                            Cancel Subscription
                        </button>
                    </form>
                </div>
            <?php else: ?>
                <!-- Pricing Plans selection -->
                <div class="plans-grid">
                    <!-- Gold Plan -->
                    <div class="plan-card">
                        <h3>Royal Club Gold</h3>
                        <div class="plan-price">$29.99<span>/mo</span></div>
                        <ul class="plan-features">
                            <li><i class='bx bx-check-circle' style="color: var(--brand-primary);"></i> Free Delivery on all dishes</li>
                            <li><i class='bx bx-check-circle' style="color: var(--brand-primary);"></i> 10% Discount on orders</li>
                            <li><i class='bx bx-check-circle' style="color: var(--brand-primary);"></i> Standard booking queue</li>
                        </ul>
                        <form action="membership.php" method="POST">
                            <input type="hidden" name="plan_name" value="Royal Club Gold">
                            <button type="submit" name="purchase_plan" class="btn btn-primary" style="width: 100%;">Subscribe Gold</button>
                        </form>
                    </div>

                    <!-- Platinum Plan -->
                    <div class="plan-card popular">
                        <span class="popular-badge">BEST VALUE</span>
                        <h3>Royal Club Platinum</h3>
                        <div class="plan-price">$49.99<span>/mo</span></div>
                        <ul class="plan-features">
                            <li><i class='bx bx-check-circle' style="color: var(--brand-primary);"></i> Free Delivery on all dishes</li>
                            <li><i class='bx bx-check-circle' style="color: var(--brand-primary);"></i> 20% Discount on orders</li>
                            <li><i class='bx bx-check-circle' style="color: var(--brand-primary);"></i> VIP front-line chef bookings</li>
                            <li><i class='bx bx-check-circle' style="color: var(--brand-primary);"></i> Direct phone support access</li>
                        </ul>
                        <form action="membership.php" method="POST">
                            <input type="hidden" name="plan_name" value="Royal Club Platinum">
                            <button type="submit" name="purchase_plan" class="btn btn-primary" style="width: 100%;">Subscribe Platinum</button>
                        </form>
                    </div>
                </div>
            <?php endif; ?>

        <?php elseif ($role == 'admin'): ?>
            <!-- Admin view active memberships -->
            <div class="table-panel">
                <h3>System Subscriber Registry</h3>
                <div class="table-responsive">
                    <table class="data-table">
                        <thead>
                            <tr>
                                <th>Membership ID</th>
                                <th>Customer Name</th>
                                <th>Customer Email</th>
                                <th>Plan Name</th>
                                <th>Price</th>
                                <th>Joined</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if ($memberships && mysqli_num_rows($memberships) > 0): ?>
                                <?php while ($row = mysqli_fetch_assoc($memberships)): ?>
                                    <tr>
                                        <td>#<?php echo $row['membership_id']; ?></td>
                                        <td><strong><?php echo htmlspecialchars($row['customer_name']); ?></strong></td>
                                        <td><?php echo htmlspecialchars($row['email']); ?></td>
                                        <td style="color: var(--brand-primary); font-weight: 500;"><?php echo htmlspecialchars($row['plan_name']); ?></td>
                                        <td>$<?php echo number_format($row['price'], 2); ?></td>
                                        <td style="font-size: 0.85rem; color: var(--text-secondary);"><?php echo date('M d, Y', strtotime($row['created_at'])); ?></td>
                                        <td>
                                            <span class="badge badge-<?php echo ($row['status'] == 'Active') ? 'success' : 'danger'; ?>">
                                                <?php echo htmlspecialchars($row['status']); ?>
                                            </span>
                                        </td>
                                    </tr>
                                <?php endwhile; ?>
                            <?php else: ?>
                                <tr><td colspan="7" style="text-align: center;">No active memberships found.</td></tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        <?php endif; ?>
    </section>
</div>

<?php include 'includes/footer.php'; ?>
