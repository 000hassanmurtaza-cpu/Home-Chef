document.addEventListener("DOMContentLoaded", function () {
    // 1. Dynamic Order Total Calculation
    const quantityInput = document.getElementById("order-quantity");
    const priceDisplay = document.getElementById("dish-unit-price");
    const totalDisplay = document.getElementById("order-total-price");

    if (quantityInput && priceDisplay && totalDisplay) {
        const calculateTotal = () => {
            const price = parseFloat(priceDisplay.innerText.replace("$", ""));
            const qty = parseInt(quantityInput.value) || 1;
            totalDisplay.innerText = "$" + (price * qty).toFixed(2);
        };

        quantityInput.addEventListener("input", calculateTotal);
        calculateTotal();
    }

    // 2. Client-side Action Confirmations
    const confirmButtons = document.querySelectorAll(".btn-confirm-delete");
    confirmButtons.forEach(button => {
        button.addEventListener("click", function (e) {
            const message = this.getAttribute("data-msg") || "Are you sure you want to delete this?";
            if (!confirm(message)) {
                e.preventDefault();
            }
        });
    });

    // 3. Auto-Dismiss Alerts after 5 seconds
    const alerts = document.querySelectorAll(".alert");
    alerts.forEach(alert => {
        setTimeout(() => {
            alert.style.transition = "opacity 0.5s ease";
            alert.style.opacity = "0";
            setTimeout(() => alert.remove(), 500);
        }, 5000);
    });
});
