<?php
require_once 'includes/config.php';
requireLogin();

$userId = getUserId();
$role = getUserRole();
$userName = getUserName();

// Initialize stats variables
$stat1 = 0; $stat2 = 0; $stat3 = 0; $stat4 = 0;
$recent_activities = [];

if ($conn) {
    if ($role == 'customer') {
        // Customer Stats
        // 1. Total orders placed
        $ord_q = mysqli_query($conn, "SELECT COUNT(*) as cnt FROM orders WHERE user_id = '$userId'");
        $stat1 = mysqli_fetch_assoc($ord_q)['cnt'] ?? 0;
        
        // 2. Total active bookings
        $book_q = mysqli_query($conn, "SELECT COUNT(*) as cnt FROM bookings WHERE customer_id = '$userId' AND status = 'Accepted'");
        $stat2 = mysqli_fetch_assoc($book_q)['cnt'] ?? 0;

        // 3. Active membership status
        $mem_q = mysqli_query($conn, "SELECT plan_name FROM membership WHERE user_id = '$userId' AND status = 'Active' LIMIT 1");
        $stat3 = (mysqli_num_rows($mem_q) > 0) ? mysqli_fetch_assoc($mem_q)['plan_name'] : 'None';

        // Fetch recent orders
        $recent_ord_q = "SELECT o.*, d.dish_name, u.name as chef_name 
                         FROM orders o 
                         JOIN dishes d ON o.dish_id = d.dish_id 
                         JOIN chefs c ON d.chef_id = c.chef_id
                         JOIN users u ON c.user_id = u.id
                         WHERE o.user_id = '$userId' 
                         ORDER BY o.order_id DESC LIMIT 5";
        $recent_activities = mysqli_query($conn, $recent_ord_q);

    } elseif ($role == 'chef') {
        // Find Chef ID
        $chefId = getChefId($userId);
        
        if ($chefId) {
            // Chef Stats
            // 1. Total dishes
            $dish_q = mysqli_query($conn, "SELECT COUNT(*) as cnt FROM dishes WHERE chef_id = '$chefId'");
            $stat1 = mysqli_fetch_assoc($dish_q)['cnt'] ?? 0;

            // 2. Pending bookings
            $book_q = mysqli_query($conn, "SELECT COUNT(*) as cnt FROM bookings WHERE chef_id = '$chefId' AND status = 'Pending'");
            $stat2 = mysqli_fetch_assoc($book_q)['cnt'] ?? 0;

            // 3. Active (Pending/Preparing) orders
            $ord_q = mysqli_query($conn, "SELECT COUNT(*) as cnt FROM orders o JOIN dishes d ON o.dish_id = d.dish_id WHERE d.chef_id = '$chefId' AND o.status IN ('Pending', 'Preparing')");
            $stat3 = mysqli_fetch_assoc($ord_q)['cnt'] ?? 0;

            // Fetch recent chef orders
            $recent_ord_q = "SELECT o.*, d.dish_name, u.name as customer_name 
                             FROM orders o 
                             JOIN dishes d ON o.dish_id = d.dish_id 
                             JOIN users u ON o.user_id = u.id
                             WHERE d.chef_id = '$chefId' 
                             ORDER BY o.order_id DESC LIMIT 5";
            $recent_activities = mysqli_query($conn, $recent_ord_q);
        }

    } elseif ($role == 'admin') {
        // Admin Stats
        // 1. Total Customers
        $cust_q = mysqli_query($conn, "SELECT COUNT(*) as cnt FROM users WHERE role = 'customer'");
        $stat1 = mysqli_fetch_assoc($cust_q)['cnt'] ?? 0;

        // 2. Total Chefs
        $chef_q = mysqli_query($conn, "SELECT COUNT(*) as cnt FROM users WHERE role = 'chef'");
        $stat2 = mysqli_fetch_assoc($chef_q)['cnt'] ?? 0;

        // 3. Total Bookings
        $book_q = mysqli_query($conn, "SELECT COUNT(*) as cnt FROM bookings");
        $stat3 = mysqli_fetch_assoc($book_q)['cnt'] ?? 0;

        // 4. Total Memberships
        $mem_q = mysqli_query($conn, "SELECT COUNT(*) as cnt FROM membership WHERE status = 'Active'");
        $stat4 = mysqli_fetch_assoc($mem_q)['cnt'] ?? 0;

        // Fetch recent registered users
        $recent_users_q = "SELECT id, name, email, role FROM users ORDER BY id DESC LIMIT 5";
        $recent_activities = mysqli_query($conn, $recent_users_q);
    }
}

include 'includes/header.php';
?>

<div class="dashboard-grid">
    <!-- Sidebar Navigation -->
    <aside class="sidebar">
        <div class="sidebar-profile">
            <div class="profile-avatar">
                <?php echo strtoupper(substr($userName, 0, 1)); ?>
            </div>
            <h3><?php echo htmlspecialchars($userName); ?></h3>
            <span class="profile-role"><?php echo $role; ?></span>
        </div>
        <ul class="sidebar-menu">
            <li><a href="dashboard.php" class="sidebar-menu-link active"><i class='bx bx-grid-alt'></i> Dashboard</a></li>
            
            <?php if ($role == 'customer'): ?>
                <li><a href="dishes.php" class="sidebar-menu-link"><i class='bx bx-dish'></i> Browse Dishes</a></li>
                <li><a href="order.php" class="sidebar-menu-link"><i class='bx bx-receipt'></i> My Orders</a></li>
                <li><a href="booking.php" class="sidebar-menu-link"><i class='bx bx-calendar'></i> Book Chef</a></li>
                <li><a href="membership.php" class="sidebar-menu-link"><i class='bx bx-crown'></i> Royal Club</a></li>
                <li><a href="review.php" class="sidebar-menu-link"><i class='bx bx-star'></i> Give Review</a></li>
            <?php elseif ($role == 'chef'): ?>
                <li><a href="dishes.php" class="sidebar-menu-link"><i class='bx bx-plus-circle'></i> Manage Dishes</a></li>
                <li><a href="order.php" class="sidebar-menu-link"><i class='bx bx-list-check'></i> Orders Received</a></li>
                <li><a href="booking.php" class="sidebar-menu-link"><i class='bx bx-calendar-event'></i> Bookings Schedule</a></li>
                <li><a href="review.php" class="sidebar-menu-link"><i class='bx bx-message-square-detail'></i> Reviews Received</a></li>
            <?php elseif ($role == 'admin'): ?>
                <li><a href="order.php" class="sidebar-menu-link"><i class='bx bx-receipt'></i> Manage Orders</a></li>
                <li><a href="membership.php" class="sidebar-menu-link"><i class='bx bx-crown'></i> Memberships</a></li>
            <?php endif; ?>
        </ul>
    </aside>

    <!-- Main Content Area -->
    <section class="dashboard-main">
        <div>
            <h2>Dashboard</h2>
            <p style="color: var(--text-secondary);">Welcome, you are logged in as <?php echo htmlspecialchars($userName); ?> (<?php echo ucfirst($role); ?>).</p>
        </div>

        <!-- Role Stats -->
        <div class="dashboard-stats">
            <?php if ($role == 'customer'): ?>
                <div class="stat-card">
                    <span class="stat-num"><?php echo $stat1; ?></span>
                    <span class="stat-label">Orders Placed</span>
                </div>
                <div class="stat-card">
                    <span class="stat-num"><?php echo $stat2; ?></span>
                    <span class="stat-label">Active Bookings</span>
                </div>
                <div class="stat-card">
                    <span class="stat-num" style="font-size: 1.4rem; padding-top: 10px;"><?php echo htmlspecialchars($stat3); ?></span>
                    <span class="stat-label">Membership Tier</span>
                </div>
            <?php elseif ($role == 'chef'): ?>
                <div class="stat-card">
                    <span class="stat-num"><?php echo $stat1; ?></span>
                    <span class="stat-label">Active Dishes</span>
                </div>
                <div class="stat-card">
                    <span class="stat-num"><?php echo $stat2; ?></span>
                    <span class="stat-label">Pending Bookings</span>
                </div>
                <div class="stat-card">
                    <span class="stat-num"><?php echo $stat3; ?></span>
                    <span class="stat-label">Active Orders</span>
                </div>
            <?php elseif ($role == 'admin'): ?>
                <div class="stat-card">
                    <span class="stat-num"><?php echo $stat1; ?></span>
                    <span class="stat-label">Total Customers</span>
                </div>
                <div class="stat-card">
                    <span class="stat-num"><?php echo $stat2; ?></span>
                    <span class="stat-label">Total Chefs</span>
                </div>
                <div class="stat-card">
                    <span class="stat-num"><?php echo $stat3; ?></span>
                    <span class="stat-label">Total Bookings</span>
                </div>
                <div class="stat-card">
                    <span class="stat-num"><?php echo $stat4; ?></span>
                    <span class="stat-label">Active Memberships</span>
                </div>
            <?php endif; ?>
        </div>

        <!-- Recent Activity Panel -->
        <div class="table-panel">
            <div class="table-panel-header">
                <h3><?php echo ($role == 'admin') ? 'Recent User Registrations' : 'Recent Orders'; ?></h3>
            </div>
            
            <div class="table-responsive">
                <table class="data-table">
                    <?php if ($role == 'customer'): ?>
                        <thead>
                            <tr>
                                <th>Order ID</th>
                                <th>Dish Name</th>
                                <th>Chef</th>
                                <th>Quantity</th>
                                <th>Total</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (mysqli_num_rows($recent_activities) > 0): ?>
                                <?php while ($row = mysqli_fetch_assoc($recent_activities)): ?>
                                    <tr>
                                        <td>#<?php echo $row['order_id']; ?></td>
                                        <td><?php echo htmlspecialchars($row['dish_name']); ?></td>
                                        <td><?php echo htmlspecialchars($row['chef_name']); ?></td>
                                        <td><?php echo $row['quantity']; ?></td>
                                        <td>$<?php echo number_format($row['total_price'], 2); ?></td>
                                        <td>
                                            <span class="badge badge-<?php 
                                                echo ($row['status']=='Completed') ? 'success' : (($row['status']=='Pending') ? 'pending' : 'info'); 
                                            ?>"><?php echo htmlspecialchars($row['status']); ?></span>
                                        </td>
                                    </tr>
                                <?php endwhile; ?>
                            <?php else: ?>
                                <tr><td colspan="6" style="text-align: center;">No orders placed yet. <a href="dishes.php" style="color: var(--brand-primary);">Browse dishes!</a></td></tr>
                            <?php endif; ?>
                        </tbody>

                    <?php elseif ($role == 'chef'): ?>
                        <thead>
                            <tr>
                                <th>Order ID</th>
                                <th>Dish Name</th>
                                <th>Customer</th>
                                <th>Quantity</th>
                                <th>Total</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if ($recent_activities && mysqli_num_rows($recent_activities) > 0): ?>
                                <?php while ($row = mysqli_fetch_assoc($recent_activities)): ?>
                                    <tr>
                                        <td>#<?php echo $row['order_id']; ?></td>
                                        <td><?php echo htmlspecialchars($row['dish_name']); ?></td>
                                        <td><?php echo htmlspecialchars($row['customer_name']); ?></td>
                                        <td><?php echo $row['quantity']; ?></td>
                                        <td>$<?php echo number_format($row['total_price'], 2); ?></td>
                                        <td>
                                            <span class="badge badge-<?php 
                                                echo ($row['status']=='Completed') ? 'success' : (($row['status']=='Pending') ? 'pending' : 'info'); 
                                            ?>"><?php echo htmlspecialchars($row['status']); ?></span>
                                        </td>
                                    </tr>
                                <?php endwhile; ?>
                            <?php else: ?>
                                <tr><td colspan="6" style="text-align: center;">No orders received yet.</td></tr>
                            <?php endif; ?>
                        </tbody>

                    <?php elseif ($role == 'admin'): ?>
                        <thead>
                            <tr>
                                <th>User ID</th>
                                <th>Name</th>
                                <th>Email</th>
                                <th>Role</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (mysqli_num_rows($recent_activities) > 0): ?>
                                <?php while ($row = mysqli_fetch_assoc($recent_activities)): ?>
                                    <tr>
                                        <td>#<?php echo $row['id']; ?></td>
                                        <td><?php echo htmlspecialchars($row['name']); ?></td>
                                        <td><?php echo htmlspecialchars($row['email']); ?></td>
                                        <td><span class="badge badge-info"><?php echo ucfirst($row['role']); ?></span></td>
                                    </tr>
                                <?php endwhile; ?>
                            <?php else: ?>
                                <tr><td colspan="4" style="text-align: center;">No users registered.</td></tr>
                            <?php endif; ?>
                        </tbody>
                    <?php endif; ?>
                </table>
            </div>
        </div>
    </section>
</div>

<?php include 'includes/footer.php'; ?>
